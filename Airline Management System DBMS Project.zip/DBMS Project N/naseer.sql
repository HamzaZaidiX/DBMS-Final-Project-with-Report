CREATE DATABASE AirlineReservation;
CREATE TABLE Aircraft(
AC_ID INT(5) PRIMARY KEY,
AC_Number VARCHAR(12),
Capacity INT(4),
Manufactured_By VARCHAR(15),
Manufactrued_On DATETIME
);
CREATE TABLE Route(
RT_ID INT(5) PRIMARY KEY,
Airport VARCHAR(20),
Destination VARCHAR(15),
Route_Code VARCHAR(10)
);

CREATE TABLE AirFare(
AF_ID INT(5) PRIMARY KEY,
Route INT(5),
Fare INT(5),
FSC INT(5)
);

CREATE TABLE Flight_Schedule(
FL_ID INT(5) PRIMARY KEY,
Flight_Date DATE,
Departure DATETIME,
Arrival DATETIME,
Aircraft INT(5),
NetFare INT(5)
);
CREATE TABLE Charges(
CH_ID INT(5) PRIMARY KEY,
Title VARCHAR(10),
Amount INT(8),
Description VARCHAR(50)
);
CREATE TABLE Countries(
CT_ID INT(5) PRIMARY KEY,
Country_Name VARCHAR(15)
);

CREATE TABLE State(
ST_ID INT(5) PRIMARY KEY,
State_Name VARCHAR(15),
Country INT(5)
);

CREATE TABLE Contact_Details(
CN_ID INT(5) PRIMARY KEY,
Email NVARCHAR(20),
Cell INT(15),
Tel INT(15),
Street VARCHAR(20),
State INT(5)
);

CREATE TABLE Passengers(
PS_ID INT(5) PRIMARY KEY,
Passenger_Name VARCHAR(15),
Address VARCHAR(30),
Age INT(2),
Nationalities VARCHAR(20),
Contacts INT(5)
);

CREATE TABLE Branches(
BR_ID INT(5) PRIMARY KEY,
Center VARCHAR(15),
Address VARCHAR(30),
State INT(5)
);

CREATE TABLE Employees(
EMP_ID INT(5) PRIMARY KEY,
Employee_Name VARCHAR(15),
Address VARCHAR(30),
Branch INT(5),
Designation VARCHAR(18),
Email NVARCHAR(20),
Tel INT(15),
Ext INT(4)
);
CREATE TABLE Transactions(
TS_ID INT(8) PRIMARY KEY,
Booking_Date DATETIME,
Departure_Date DATETIME,
Passenger INT(5),
Flight INT(5),
Confirmation VARCHAR(15),
Employee INT(5),
Charges INT(8),
Total INT(10)
);

INSERT INTO Aircraft(AC_ID, AC_Number, Capacity, Manufactured_By, Manufactrued_On) VALUES
(17875, 'LAX-875', 300, 'Boeing', '17-08-21 10:21:04 AM'),
(18235, 'PK-235', 500, 'Gulf Stream', '18-11-15 04:40:38 PM'),
(16145, 'LAX-145', 700, 'Bombardier', '16-03-17 02:15:21 PM'),
(17325, 'LAX-325', 300, 'Boeing', '17-11-30 01:06:55 PM'),
(15215, 'CXZ-215', 700, 'Textron', '15-03-11 09:00:31 AM'),
(19315, 'RYD-315', 500, 'Gulf Stream', '19-01-03 03:12:51 PM'),
(11685, 'MK-685', 300, 'Boeing', '11-04-11 10:45:16 AM'),
(13005, 'CXZ-005', 700, 'Bombardier', '13-01-25 04:55:05 PM'),
(15255, 'PK-255', 700, 'Textron', '15-03-18 11:35:18 AM'),
(19115, 'RYD-115', 500, 'Gulf Stream', '19-08-31 06:15:34 PM'),
(16105, 'MK-105', 800, 'Boeing', '16-09-23 02:11:09 PM'),
(17195, 'PK-195', 800, 'Gulf Stream', '17-10-16 09:45:32 AM');

INSERT INTO airfare(AF_ID, Route, Fare, FSC) VALUES
(10144, 15, 60000, 12000),
(12875, 04, 25000, 4000),
(19312, 11, 38000, 6000),
(11341, 38, 71000, 15000),
(19184, 21, 65000, 14000),
(10456, 07, 13000, 3000),
(16475, 68, 85000, 15000),
(18432, 13, 40000, 8000),
(11215, 23, 55000, 15000),
(18654, 77, 80000, 18000),
(19875, 91, 18000, 5000);


INSERT INTO branches(BR_ID, Center, Address, State) VALUES
(01, 'Brooklyn', '3rd Avenue', 8),
(02, 'California', '21st Avenue', 9),
(03, 'Karachi', '14th Avenue', 1),
(04, 'Islamabad', '3rd Avenue', 2),
(05, 'London', '11th Avenue', 10),
(06, 'Liverpool', '8th Avenue', 11),
(07, 'South Hampton', '17th Avenue', 12),
(08, 'Barcelona', '25th Avenue', 5),
(09, 'Madrid', '19th Avenue', 6),
(10, 'Valencia', '22nd Avenue', 7),
(11, 'Perth', '4th Avenue', 3),
(12, 'Sydney', '31st Avenue', 4),
(13, 'Wellington', '11th Avenue', 13),
(14, 'Auckland', '5th Avenue', 14);

INSERT INTO charges(CH_ID, Title, Amount, Description) VALUES
(2678, 'SYD-PER', 29000,'Additional 1000/= for Extra Luggage Limit'),
(2985, 'PER-WEL', 16000,'Additional 4000/= for Extra Luggage Limit'),
(2267, 'LND-CAL', 44000,'Additional 1000/= for Extra Luggage Limit'),
(2185, 'MRD-LND', 48000,'Additional 2000/= for Extra Luggage Limit'),
(2886, 'BRK-BAR', 72000,'Additional 3000/= for Extra Luggage Limit'),
(2115, 'BAR-KHI', 79000,'Additional 1000/= for Extra Luggage Limit'),
(2224, 'KHI-LIV', 70000,'Additional 5000/= for Extra Luggage Limit'),
(2009, 'AUK-VAL', 86000,'Additional 4000/= for Extra Luggage Limit'),
(2348, 'BAR-CAL', 100000,'Additional 10000/= for Extra Luggage Limit'),
(2912, 'SHM-ISB', 98000,'Additional 2000/= for Extra Luggage Limit'),
(2812, 'KHI-ISB', 23000,'Additional 2000/= for Extra Luggage Limit');



INSERT INTO contact_details(CN_ID, Email, Cell, Tel, Street, State) VALUES
(318, 'max@gmail.com', 6317178188, 6536635, '21st Avenue', 8),
(319, 'jason@live.com', 78378487838, 6534635, '3rd Avenue', 10),
(320, 'carl@hotmail.com', 73783873893, 72626727, '18th Avenue', 6),
(321, 'anderson@yahoo.com', 3837387383, 2899287, '7th Avenue',12 ),
(322, 'jerry@hotmail.com', 84738748378, 822727627, '31st Avenue', 9),
(323, 'michelle@gmail.com', 36363673733, 824874872, '9th Avenue', 3),
(324, 'carlisle@live.com', 33637637376, 736726772, '11th Avenue', 11),
(325, 'carlos@yahoo.com', 62763527265, 62535265, '21st Avenue', 7),
(326, 'nicole@gmail.com', 63126562652, 82862627, '7th Avenue', 14),
(327, 'jasmine@hotmail.com', 3627637226, 97863663, '14th Avenue', 4),
(328, 'asad@yahoo.com', 73781788171, 78374328, '21st Avenue', 1),
(329, 'lance@gmail.com', 65361563511, 83298228, '3rd Avenue', 9),
(330, 'ayesha@hotmail.com', 3165616166, 823828828, '18th Avenue', 2),
(331, 'mark@live.com', 7889282922, 632872982, '7th Avenue', 10),
(332, 'julian@yahoo.com', 1563616616, 727272872, '31st Avenue', 5),
(333, 'megan@gmail.com', 67381919181, 983883933, '9th Avenue', 11),
(334, 'richard@gmail.com', 9182381818, 748272889, '11th Avenue', 4),
(335, 'shahzad@live.com', 2122272728, 482772872, '21st Avenue', 1),
(336, 'kristen@yahoo.com', 71676222245, 2871838918, '7th Avenue', 13),
(337, 'kamal@gmail.com', 382728289829, 189318898, '14th Avenue', 2);

INSERT INTO countries(CT_ID, Country_Name) VALUES
(001, 'Pakistan'),
(002, 'Australia'),
(003, 'Spain'),
(004, 'USA'),
(005, 'England'),
(006, 'New Zealand');

INSERT INTO employees(EMP_ID, Employee_Name, Address, Branch, Designation, Email, Tel, Ext) VALUES
(4401, 'Jason', '31st Avenue', 1, 'Officer', 'jason@net.co', 414872611, 111),
(4402, 'Adam', '16th Avenue', 2, 'Officer', 'adam@net.co', 414872611, 110),
(4405, 'Rahim', '23rd Avenue', 3, 'Officer', 'rahim@net.co', 414872615, 515),
(4408, 'Ali', '6th Avenue', 4, 'Officer', 'ali@net.co', 414872614, 412),
(4411, 'Marc', '18th Avenue', 5, 'Officer', 'marc@net.co', 414872613, 345),
(4419, 'Charles', '14th Avenue', 6, 'Officer', 'charles@net.co', 414872613, 344),
(4423, 'Madison', '23rd Avenue', 7, 'Officer', 'madison@net.co', 414872611, 161),
(4427, 'Ana', '22nd Avenue', 8, 'Officer', 'ana@net.co', 414872611, 160),
(4431, 'Parker', '7th Avenue', 9, 'Officer', 'parker@net.co', 414872612, 271),
(4435, 'Anderson', '9th Avenue', 10, 'Officer', 'anderson@net.co', 414872614, 413),
(4441, 'James', '6th Avenue', 11, 'Officer', 'james@net.co', 414872612, 270),
(4449, 'Jacob', '18th Avenue', 12, 'Officer', 'jacob@net.co', 414872613, 361),
(4473, 'Cameron', '11th Avenue', 13, 'Officer', 'cameron@net.co', 414872615, 518),
(4485, 'Mark', '5th Avenue', 14, 'Officer', 'mark@net.co', 414872614, 415);

INSERT INTO flight_schedule(FL_ID, Flight_Date, Departure, Arrival, Aircraft, NetFare) VALUES
(56141, '19-05-01', '19-05-01 08:00:00AM', '19-05-01 11:00:00PM', 18235, 10144),
(56142, '19-05-01', '19-05-01 08:30:00AM', '19-05-01 12:00:00PM', 15215, 10456),
(56143, '19-05-01', '19-05-01 02:00:00PM', '19-05-02 10:00:00AM', 16145, 11215),
(56144, '19-05-01', '19-05-01 05:30:00PM', '19-05-02 08:30:00PM', 15255, 11341),
(56145, '19-05-02', '19-05-02 08:00:00AM', '19-05-02 01:00:00PM', 11685, 12875),
(56146, '19-05-02', '19-05-02 08:30:00AM', '19-05-03 11:30:00AM', 17875, 16475),
(56147, '19-05-02', '19-05-02 09:00:00AM', '19-05-02 07:00:00PM', 16105, 18432),
(56148, '19-05-03', '19-05-03 08:00:00AM', '19-05-04 10:00:00AM', 19115, 18654),
(56149, '19-05-03', '19-05-03 03:30:00PM', '19-05-04 08:00:00AM', 17195, 19184),
(56150, '19-05-04', '19-05-04 11:00:00AM', '19-05-04 10:00:00PM', 13005, 19312),
(56151, '19-05-04', '19-05-04 02:00:00AM', '19-05-04 05:00:00PM', 19315, 19875),
(56152, '19-05-04', '19-05-04 01:30:00PM', '19-05-05 11:30:00PM', 15255, 16475),
(56153, '19-05-05', '19-05-05 08:00:00AM', '19-05-06 06:00:00AM', 16105, 19184),
(56154, '19-05-05', '19-05-05 09:00:00AM', '19-05-05 03:00:00PM', 18235, 10456),
(56155, '19-05-06', '19-05-06 10:00:00AM', '19-05-06 11:00:00AM', 15215, 10144),
(56156, '19-05-06', '19-05-06 12:00:00PM', '19-05-06 07:00:00PM', 11685, 18432);


INSERT INTO passengers(PS_ID, Passenger_Name, Address, Age, Nationalities, Contacts) VALUES
(6617, 'Max', '21st Avenue', 23, 'American', 318),
(6618, 'Jason', '3rd Avenue', 26, 'British', 319),
(6619, 'Carl', '18th Avenue', 23, 'Spanish', 320),
(6620, 'Anderson', '7th Avenue', 20, 'British', 321),
(6621, 'Jerry', '31st Avenue', 24, 'American', 322),
(6622, 'Michelle', '9th Avenue', 21, 'Australian', 323),
(6623, 'Carlisle', '11th Avenue', 30, 'British', 324),
(6624, 'Carlos', '21st Avenue', 23, 'Spanish', 325),
(6625, 'Nicole', '7th Avenue', 22, 'New Zealander', 326),
(6626, 'Jasmine', '14th Avenue', 29, 'Australian', 327),
(6627, 'Asad', '21st Avenue', 21, 'Pakistani', 328),
(6628, 'Lance', '3rd Avenue', 24, 'American', 329),
(6629, 'Ayesha', '18th Avenue', 21, 'Pakistani', 330),
(6630, 'Mark', '7th Avenue', 20, 'British', 331),
(6631, 'Julian', '31st Avenue', 24, 'Spanish', 332),
(6632, 'Megan', '9th Avenue', 21, 'British', 333),
(6633, 'Richard', '11th Avenue', 30, 'Australian', 334),
(6634, 'Shahzad', '21st Avenue', 23, 'Pakistani', 335),
(6635, 'Kristen', '7th Avenue', 22, 'New Zealander', 336),
(6636, 'Kamal', '14th Avenue', 19, 'Pakistani', 337);


INSERT INTO route(RT_ID, Airport, Destination, Route_Code) VALUES
(15, 'Brooklyn Int.', 'Barcelona Int.', 'BRK-BAR'),
(7, 'Perth Int.', 'Wellington Int.', 'PER-WEL'),
(23, 'Karachi Int.', 'Liverpool Int.', 'KHI-LIV'),
(38, 'Auckland Int.', 'Valencia Int.', 'AUK-VAL'),
(4, 'Sydney Int.', 'Perth Int.', 'SYD-PER'),
(68, 'Barcelona Int.', 'California Int.', 'BAR-CAL'),
(13, 'Madrid Int.', 'London Int.', 'MRD-LND'),
(77, 'South Hampton Int.', 'Islamabad Int.', 'SHM-ISB'),
(21, 'Barcelona Int.', 'Karachi Int.', 'BAR-KHI'),
(11, 'London Int.', 'California Int.', 'LND-CAL'),
(91, 'Karachi Int.', 'Islamabad Int.', 'KHI-ISB');

INSERT INTO state(ST_ID, State_Name, Country) VALUES
(1, 'Karachi', 1),
(2, 'Islamabad', 1),
(3, 'Perth', 2),
(4, 'Sydney', 2),
(5, 'Barcelona', 3),
(6, 'Madrid', 3),
(7, 'Valencia', 3),
(8, 'Brooklyn', 4),
(9, 'California', 4),
(10, 'London', 5),
(11, 'Liverpool', 5),
(12, 'South Hampton', 5),
(13, 'Wellington', 6),
(14, 'Auckland', 6);

INSERT INTO transactions(TS_ID, Booking_Date, Departure_Date, Passenger, Flight, Confirmation, Employee, Charges, Total) VALUES
(1001, '19-04-03 12:00:00PM', '2019-05-01 08:00:00', 6617, 56141, 'Confirmed', 4401, 2886, 75000),
(1002, '19-04-03 01:00:00PM', '2019-05-04 11:00:00', 6618, 56150, 'Confirmed', 4411, 2267, 44000),
(1003, '19-04-03 02:00:00PM', '2019-05-02 09:00:00', 6619, 56147, 'Confirmed', 4431, 2185, 50000),
(1004, '19-04-03 02:00:00PM', '2019-05-03 08:00:00', 6620, 56148, 'Confirmed', 4423, 2912, 98000),
(1005, '19-04-03 03:00:00PM', '2019-05-02 08:30:00', 6621, 56146, 'Confirmed', 4402, 2348, 100000),
(1006, '19-04-03 03:00:00PM', '2019-05-01 08:30:00', 6622, 56142, 'Not-Confirmed', 4441, 2985, 20000),
(1007, '19-04-03 03:00:00PM', '2019-05-01 02:00:00', 6623, 56143, 'Confirmed', 4419, 2224, 70000),
(1008, '19-04-03 04:00:00PM', '2019-05-01 05:30:00', 6624, 56144, 'Confirmed', 4435, 2009, 86000),
(1009, '19-04-03 05:00:00PM', '2019-05-03 05:30:00', 6625, 56144, 'Not-Confirmed', 4485, 2009, 90000),
(1010, '19-04-03 07:00:00PM', '2019-05-02 08:00:00', 6626, 56145, 'Confirmed', 4449, 2678, 29000),
(1011, '19-04-03 12:00:00PM', '2019-05-04 02:00:00', 6627, 56151, 'Confirmed', 4405, 2812, 25000),
(1012, '19-04-03 01:00:00PM', '2019-05-04 11:00:00', 6628, 56150, 'Confirmed', 4402, 2267, 44000),
(1013, '19-04-03 02:00:00PM', '2019-05-03 08:00:00', 6629, 56148, 'Confirmed', 4408, 2912, 98000),
(1014, '19-04-03 02:00:00PM', '2019-05-02 09:00:00', 6630, 56147, 'Confirmed', 4411, 2185, 50000),
(1015, '19-04-03 03:00:00PM', '2019-05-03 03:30:00', 6631, 56149, 'Not-Confirmed', 4427, 2115, 79000),
(1016, '19-04-03 03:00:00PM', '2019-05-01 02:00:00', 6632, 56143, 'Confirmed', 4419, 2224, 75000),
(1017, '19-04-03 03:00:00PM', '2019-05-02 08:00:00', 6633, 56145, 'Confirmed', 4449, 2678, 29000),
(1018, '19-04-03 04:00:00PM', '2019-05-01 02:00:00', 6634, 56143, 'Confirmed', 4405, 2224, 70000),
(1019, '19-04-03 05:00:00PM', '2019-05-05 09:00:00', 6635, 56154, 'Not-Confirmed', 4473, 2985, 20000),
(1020, '19-04-03 07:00:00PM', '2019-05-03 08:00:00', 6636, 56148, 'Confirmed', 4408, 2912, 98000);


SELECT * , MAX(Amount) FROM charges;

SELECT * FROM transactions WHERE Charges = (SELECT MAX(Charges)
 FROM transactions WHERE charges <>(SELECT MAX(Charges) FROM transactions)); 

SELECT center FROM branches GROUP BY center;

SELECT branch FROM employees GROUP BY branch HAVING COUNT(*) < 2;

SELECT * FROM employees WHERE branch IN (
SELECT branch FROM employees GROUP BY branch HAVING COUNT(*) < 2);

SELECT Employee_Name FROM employees WHERE branch IN (
SELECT branch FROM employees GROUP BY branch HAVING COUNT(*) < 2);

SELECT * FROM passengers;

SELECT Passenger_Name, Address, Contacts FROM passengers;

SELECT * FROM transactions WHERE TS_ID = 1010;

SELECT Email FROM contact_details WHERE CN_ID = 322;

SELECT Flight_Date, NetFare FROM flight_schedule JOIN transactions
ON flight_schedule.FL_ID = transactions.FL_ID WHERE FL_ID = 56146;

SELECT Passenger, Charges FROM transactions WHERE Total = 50000 OR Total = 75000;

SELECT * FROM transactions;

SELECT SUM(Total) FROM transactions WHERE Total > 70000;

SELECT DISTINCT Charges FROM transactions;

SELECT * FROM transactions WHERE Total IN (
SELECT MAX(Total) FROM transactions);

DDL

ALTER TABLE employees ADD(Salary INT(8));

UPDATE Employees SET Salary = 45000 WHERE EMP_ID = 4401; 




